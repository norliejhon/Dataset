<?php
include 'dbconnection.php';
if(isset($_GET['delete'])){ // Change 'delete' to 'id_number'
    $id_number = $_GET['delete']; // Change 'delete' to 'id_number'

    $sql = "DELETE FROM user WHERE id_number='$id_number'"; // Enclose $id_number in quotes
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
        echo '<script>alert("User Successfully Deleted");</script>';
    } else {
        echo '<script>alert("Error Deleting User");</script>';
    }

    echo '<script>window.location.href = "user.php";</script>';
    exit();
}
?>
