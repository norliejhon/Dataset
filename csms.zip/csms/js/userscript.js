document.addEventListener('DOMContentLoaded', function() {
    const rowsPerPage = 7;
    let currentPage = 1;
    const table = document.getElementById('userTable');
    const tbody = table.querySelector('tbody');
    let rows = Array.from(tbody.querySelectorAll('tr'));
    let filteredRows = rows;
    const totalRows = rows.length;
    const totalPages = Math.ceil(totalRows / rowsPerPage);

    // Insert the No Result Found row
    const noResultRow = document.createElement('tr');
    noResultRow.id = 'noResultRow';
    noResultRow.style.display = 'none';
    noResultRow.innerHTML = '<td colspan="11" style="text-align: center;"><h3>No Result Found</h3></td>';
    tbody.appendChild(noResultRow);

    function displayRows() {
        tbody.innerHTML = '';
        const start = (currentPage - 1) * rowsPerPage;
        const end = Math.min(start + rowsPerPage, filteredRows.length);
        if (filteredRows.length === 0) {
            noResultRow.style.display = '';
            tbody.appendChild(noResultRow);
        } else {
            noResultRow.style.display = 'none';
            for (let i = start; i < end; i++) {
                tbody.appendChild(filteredRows[i]);
            }
        }
        document.getElementById('pageInfo').innerText = `Page ${currentPage} of ${Math.ceil(filteredRows.length / rowsPerPage)}`;
        document.getElementById('prevPage').disabled = currentPage === 1;
        document.getElementById('nextPage').disabled = currentPage === Math.ceil(filteredRows.length / rowsPerPage);
    }

    document.getElementById('prevPage').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            displayRows();
        }
    });

    document.getElementById('nextPage').addEventListener('click', function() {
        if (currentPage < Math.ceil(filteredRows.length / rowsPerPage)) {
            currentPage++;
            displayRows();
        }
    });

    function searchRecord() {
        const input = document.querySelector(".record-search").value.toUpperCase();
        filteredRows = rows.filter(row => {
            return Array.from(row.cells).some(cell => cell.textContent.toUpperCase().includes(input));
        });
        currentPage = 1;
        displayRows();
    }

    document.querySelector(".record-search").addEventListener('input', searchRecord);

    displayRows();
});