-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2024 at 10:40 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csms`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_number` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `faculty` varchar(50) NOT NULL,
  `program` varchar(50) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `status` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_number`, `last_name`, `first_name`, `middle_name`, `faculty`, `program`, `user_type`, `status`, `email`, `username`, `password`) VALUES
('12345', 'Super Admin1', 'Super Admin1', '', 'FCDSET', 'BSIT', 'Loading in Charge', 'Accepted', '1@1', 'superadmin1', '$2y$10$o5ozOdxpbe51mWXFuHtFbe0BLJCmR0HXIRWlVHCDyEBeEoZ5ImDJa'),
('3234', 'Malagdao', 'Norlie', '3', 'FCDSET', 'BSIT', 'Faculty', 'Accepted', '3@3', 'norlie', '$2y$10$EGgEKioiZ7yR47OAFSjHB.GeP.aAQO2OzcNmBz0wh61iDQ5BZP1yK'),
('32341', 'user', 'user', '3', 'FCDSET', 'BSIT', 'Faculty', 'Rejected', '3@3', 'user', '$2y$10$ovmcngiVUgvrV08sFBQcJeBt0W0O43uTXeE4CpewXBZlKMMUMrA/a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
