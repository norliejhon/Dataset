<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

	<div class="index-main">
	 		<nav class="header "> 
	 		<img src="img/dorsulogo.png" alt="Davao Oriental State University Logo">
	 			<div class="header-text">
	 				<h1 class="school_name">DAVAO ORIENTAL STATE UNIVERSITY</h1>
                	<h6 class="faculty_name">A University of Excellece, Innovation, and Inclusion</h6>
	 			</div>
	 		</nav>
	 		<main>
    <div class="index-content">
        <div class="form-content">
            <div class="left-side">
                <img src="img/csmslogo.png" alt="CSMS LOGO"> <br>
                <p class="greetings">Welcome Back!</p>
                <p class="instruction">Enter your credentials<br>to &nbsp;&nbsp;&nbsp;&nbsp;access &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the <br>platform.</p>
            </div>
            <div class="right-side">
                <form class="login-form" action="login_process.php" method="POST">
                    <h3 class="login">Log In</h3>
                    <input class="username" type="username" name="username" placeholder="username" required><br><br>
                    <input type="password" name="password" placeholder="Password" required><br>
                    
                    <button class="index" type="submit">login</button><br>
                    <a href="#">Forgot Password?</a><br>
                    <a href="#addnew" data-toggle="modal" class="btn btn-primary" style="background-color: gray; border: none;"><span class="glyphicon glyphicon-plus"></span>Create Account</a>
                </form>    
            </div>
        </div>
        <div class="summary">
        	<!--Some content-->
        </div>
    </div>
</main>
<div class="footer">
	 			<!---Add some content-->
	 		</div>
	 	</div>
	<?php include('add_modal.php') ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>