<?php
include 'dbconnection.php';

$id_number = $_GET['update'];
$sql = "SELECT * FROM user WHERE id_number=$id_number";
$result = mysqli_query($conn, $sql);

if ($result) {
    $row = mysqli_fetch_assoc($result);

    $id_number = $row['id_number'];
    $last_name = $row['last_name'];
    $first_name = $row['first_name'];
    $middle_name = $row['middle_name'];
    $faculty = $row['faculty'];
    $program = $row['program'];
    $user_type = $row['user_type'];
    $status = $row['status'];
    $email = $row['email'];
    $username = $row['username'];

} else {
    echo '<script>alert("Error fetching data");</script>';
    die(mysqli_error($conn));
}

if (isset($_POST['submit'])) {
    $status = $_POST['status'];

    $sql = "UPDATE user SET status='$status' WHERE id_number='$id_number'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo '<script>alert("User Status Updated Successfully");</script>';
        echo '<script>window.location.href = "user.php";</script>';
        exit(); 
    } else {
        echo '<script>alert("Error updating..!!");</script>';
        die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .form-container {
    max-width: 500px;
    margin: 30px auto;
    padding: 15px;
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    background-color: #f5f5f5;
}

.form-container h2 {
    font-size: 1.2rem;
    text-align: center;
    margin-bottom: 10px;
}
.form-container button i{
    color: black;
    font-size: 14px;
}

.form-container .form-label {
    font-weight: bold;
}

.form-container .btn-primary {
    margin-bottom: 10px;
    width: 100%;
    padding: 6px;
}

.form-container .form-control[disabled] {
    background-color: #e9ecef;
}

    </style>
</head>
<body>
    
    <input type="checkbox" id="menu-toggle" hidden>
    <div class="wrapper">
        <aside id="sidebar">
            <div class="top-nav">
                <div class="logo">
                    <img src="img/csmslogo.png">
                    <a>Admin</a>
                </div>
                <ul class="sidebar-nav">
                    <li class="sidebar-items">
                        <a href="dashboard.php" class="sidebar-link">
                            <i class="fa-solid fa-table-columns pe-2"></i><span class="text dashboard">Dashboard</span>
                        </a>
                    </li>
                    <li class="sidebar-items">
                        <a href="user.php" class="active" class="sidebar-link">
                            <i class="fa-regular fa-user pe-2"></i><span class="text">Users</span>
                        </a>
                    </li>
                    <li class="sidebar-items">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#manage" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-list-check pe-2"></i><span class="text">Manage</span></a>
                        <ul id="manage" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-items">
                            <a href="courses.php" class="sidebar-link"><i class="fa-solid fa-book pe-1"></i>Courses</a>
                        </li>
                        <li class="sidebar-items">
                            <a href="rooms.php" class="sidebar-link"><i class="fa-solid fa-house-chimney pe-1"></i>Rooms</a>
                        </li>
                        </ul>
                    </li>
                    <li class="sidebar-items">
                        <a href="schedule.php" class="sidebar-link">
                            <i class="fa-regular fa-calendar pe-2"></i>
                            <span class="text">Schedule</span>
                        </a>
                    </li>
                    <li class="sidebar-items">
                        <a href="reports.php" class="sidebar-link">
                            <i class="fa-regular fa-flag pe-2"></i>
                            <span class="text">Reports</span>
                        </a>
                    </li>
                    <label for="menu-toggle">
                    <span><i class="fa-solid fa-arrow-right-to-bracket"></i></span>
                </label>
                </ul>
            </div>
        </aside>
        <div class="main">
            <nav class="navbar navbar-expand"> 
            <img src="img/dorsulogo.png" alt="Davao Oriental State University Logo">
                <div class="text-header">
                    <h1 class="school_name">DAVAO ORIENTAL STATE UNIVERSITY</h1>
                    <h6 class="faculty_name">A University of Excellence, Innovation, and Inclusion</h6>
                </div>
                <div class="navbar-collapse">
                    <ul class="navbar-nav">
                        <div class="side-content">
                    
                        <div class="notification">
                            <i class="fa-regular fa-bell"></i>
                        </div>
                        </div>
                        <li class="nav-item" dropdown>
                            <a href="#" data-bs-toggle="dropdown" class="nav-icon">
                                <img src="img/user-profile.png" class="avatar img-fluid rounded" alt="Profile">
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="#" class="dropdown-item"><i class="fa-regular fa-user"></i>Profile</a>
                                <a href="#" class="dropdown-item"><i class="fa-solid fa-gear"></i>Setting</a>
                                <a href="index.php" class="dropdown-item"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container form-container">
                <button ><a href="user.php"><i class="fa-solid fa-x"></i></a></button>
                <h2>Update User Status</h2>
                <form method="POST">
    <input type="hidden" name="id_number" value="<?php echo $id_number; ?>">
    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label for="last_name" class="form-label">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $last_name; ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="program" class="form-label">Program:</label>
                <input type="text" class="form-control" id="program" name="program" value="<?php echo $program; ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="user_type" class="form-label">Role:</label>
                <input type="text" class="form-control" id="user_type" name="user_type" value="<?php echo $user_type; ?>" disabled>
            </div>
            
        </div>
        <div class="col-md-6">
            
            <div class="mb-3">
                <label for="first_name" class="form-label">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $first_name; ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="faculty" class="form-label">Faculty:</label>
                <input type="text" class="form-control" id="faculty" name="faculty" value="<?php echo $faculty; ?>" disabled>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status:</label>

                <select class="form-control" id="status" name="status" required>
                                    <option value="" disabled selected>Change Status</option>
                                    <option value="Accepted">Accept</option>
                                    <option value="Rejected">Reject</option>
                                    
                                </select>

            </div>
        </div>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Save Changes</button>
</form>

            </div>
        </div>
    </div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


</body>
</html>
