<?php
// register.php

require_once 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize input
    $id_number = htmlspecialchars($_POST["id_number"]);
    $last_name = htmlspecialchars($_POST["last_name"]);
    $first_name = htmlspecialchars($_POST["first_name"]);
    $middle_name = htmlspecialchars($_POST["middle_name"]);
    $faculty = htmlspecialchars($_POST["faculty"]);
    $program = htmlspecialchars($_POST["program"]);
    $user_type = htmlspecialchars($_POST["user_type"]);
    $status = htmlspecialchars($_POST["status"]);
    $email = htmlspecialchars($_POST["email"]);
    $username = htmlspecialchars($_POST["username"]);
    $password = $_POST["password"];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if username already exists
    $checkUsernameQuery = $conn->prepare("SELECT * FROM user WHERE username = ?");
    $checkUsernameQuery->bind_param("s", $username);
    $checkUsernameQuery->execute();
    $result = $checkUsernameQuery->get_result();
    $usernameExists = $result->fetch_assoc();

    if ($usernameExists) {
        echo '<script>';
        echo 'alert("Username already exists. Please try again.");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
        exit();
    }

    // Check if username already exists
    $checkIDQuery = $conn->prepare("SELECT * FROM user WHERE id_number = ?");
    $checkIDQuery->bind_param("s", $id_number);
    $checkIDQuery->execute();
    $result = $checkIDQuery->get_result();
    $idExists = $result->fetch_assoc();

    if ($idExists) {
        echo '<script>';
        echo 'alert("ID Number already exists. Please try again.");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
        exit();
    }

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO user (id_number, last_name, first_name, middle_name, faculty, program, user_type, status, email, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $id_number, $last_name, $first_name, $middle_name, $faculty, $program, $user_type, $status, $email, $username, $hashed_password);

    if ($stmt->execute()) {
        echo '<script>';
        echo 'alert("Account Successfully Created Wait for some confirmation to fully access the platform. Thank You");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
    } else {
        echo '<script>';
        echo 'alert("Error: Unable to register.");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
    }

    $stmt->close();
    $checkUsernameQuery->close();
} else {
    header("Location: index.php");
    exit();
}

$conn->close();
?>
