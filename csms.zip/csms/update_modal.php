<?php
$isUpdating = isset($user); // Check if we're updating an existing user
$id_number = $isUpdating ? $user['id_number'] : '';
$last_name = $isUpdating ? $user['last_name'] : '';
$first_name = $isUpdating ? $user['first_name'] : '';
$middle_name = $isUpdating ? $user['middle_name'] : '';
$faculty = $isUpdating ? $user['faculty'] : '';
$program = $isUpdating ? $user['program'] : '';
$user_type = $isUpdating ? $user['user_type'] : '';
$status = $isUpdating ? $user['status'] : '';
$email = $isUpdating ? $user['email'] : '';
$username = $isUpdating ? $user['username'] : '';
?>
<div class="modal" id="userModal">
    <form action="updateUser.php" method="POST">
        <input type="hidden" name="id_number" value="<?php echo $id_number; ?>">
        <!-- Add the rest of the form fields with pre-populated data if updating -->
        <input type="text" name="last_name" value="<?php echo $last_name; ?>">
        <input type="text" name="first_name" value="<?php echo $first_name; ?>">
        <input type="text" name="middle_name" value="<?php echo $middle_name; ?>">
        <!-- Add the rest of the fields similarly -->
        <button type="submit">Save Changes</button>
    </form>
</div>
