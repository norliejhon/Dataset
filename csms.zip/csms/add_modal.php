<!-- Add New -->
<script>
    function validateForm() {
            var password = document.forms["registrationForm"]["password"].value;
            var confirmPassword = document.forms["registrationForm"]["confirm_password"].value;
            var passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

            if (!passwordPattern.test(password)) {
                alert("Password must contain at least 1 number, 1 uppercase letter, 1 special character, and be at least 8 characters long.");
                return false;
            }

            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }

function updateProgram() {
    var facultyDropdown = document.getElementById("faculty");
    var programDropdown = document.getElementById("program");

    var selectedFaculty = facultyDropdown.value;

    programDropdown.innerHTML = '<option value="" disabled selected>Select Program</option>';

    switch (selectedFaculty) {
        case "FCDSET":
            programDropdown.innerHTML +=
                '<option value="BSIT">BSIT</option>' +
                '<option value="BSCE">BSCE</option>' +
                '<option value="BSMRS">BSMRS</option>' +
                '<option value="BITM">BITM</option>';
            break;
        case "FTED":
            programDropdown.innerHTML +=
                '<option value="BEED">BEED</option>' +
                '<option value="BPED">BPED</option>' +
                '<option value="BSED">BSED</option>';
            break;
        case "FNAHS":
            programDropdown.innerHTML += '<option value="BSN">BSN</option>';
            break;
        case "FGBM":
            programDropdown.innerHTML +=
                '<option value="BSC">BSC</option>' +
                '<option value="BSBA">BSBA</option>' +
                '<option value="BSHM">BSHM</option>';
            break;
        case "FALS":
            programDropdown.innerHTML +=
                '<option value="BSB">BSB</option>' +
                '<option value="BSES">BSES</option>' +
                '<option value="BSAM">BSAM</option>' +
                '<option value="BSA">BSA</option>' +
                '<option value="BSDC">BSDC</option>';
            break;
        // Add cases for other faculties if needed
    }
}
</script>

<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title text-center" id="myModalLabel">&nbsp;Create Account</h4>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <form name="registrationForm" method="POST" onsubmit="return validateForm()" action="create_account_process.php">
                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">ID No:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="id_number" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Last Name:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="last_name" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">First Name:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="first_name" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Middle Name:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="middle_name">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Faculty:</label>
                            <div class="col-sm-12 position-relative">
                                <select name="faculty" id="faculty" class="form-control" required onchange="updateProgram()">
                                    <option value="" disabled selected>Select faculty</option>
                                    <option value="FCDSET">FCDSET</option>
                                    <option value="FTED">FTED</option>
                                    <option value="FNAHS">FNAHS</option>
                                    <option value="FGBM">FGBM</option>
                                    <option value="FALS">FALS</option>
                                </select>
                                <i class="fa fa-caret-down position-absolute" style="right: 20px; top: 50%; transform: translateY(-50%); pointer-events: none;"></i>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Program:</label>
                            <div class="col-sm-12 position-relative">
                                <select id="program" name="program" class="form-control" required>
                                    <option value="" disabled selected>Select Program</option>
                                    <!-- Program options will be dynamically populated based on faculty selection -->
                                </select>
                                <i class="fa fa-caret-down position-absolute" style="right: 20px; top: 50%; transform: translateY(-50%); pointer-events: none;"></i>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Role:</label>
                            <div class="col-sm-12 position-relative">
                                <select id="user_type" name="user_type" class="form-control" required>
                                    <option value="" disabled selected>Select Role</option>
                                    <option value="Faculty">Faculty</option>
                                    <option value="Loading in Charge">Loading in Charge/Admin</option>
                                </select>
                                <i class="fa fa-caret-down position-absolute" style="right: 20px; top: 50%; transform: translateY(-50%); pointer-events: none;"></i>
                            </div>
                        </div>

                        <div class="form-group row" hidden>
                            <label class="control-label modal-label col-sm-12">Status:</label>
                            <div class="col-sm-12">
                                <input type="text" value="Pending" class="form-control" name="status" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Email:</label>
                            <div class="col-sm-12">
                                <input type="email" class="form-control" name="email" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Username:</label>
                            <div class="col-sm-12">
                                <input type="text" class="form-control" name="username" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Password:</label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control" name="password" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="control-label modal-label col-sm-12">Confirm Password:</label>
                            <div class="col-sm-12">
                                <input type="password" class="form-control" name="confirm_password" required>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">
                                <span class="glyphicon glyphicon-remove"></span> Cancel
                            </button>
                            <button type="submit" name="add" class="btn btn-primary">
                                <span class="glyphicon glyphicon-floppy-disk"></span> Save
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
