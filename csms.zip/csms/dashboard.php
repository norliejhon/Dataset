<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
	
	<input type="checkbox" id="menu-toggle" hidden>
	 <div class="wrapper">
	 	<aside id="sidebar">

	 		<div class="top-nav">
	 			<div class="logo">
	 				<img src="img/csmslogo.png">
	 				<a>Super Admin</a>
	 			</div>
	 			
	 			<ul class="sidebar-nav">

	 				<li class="sidebar-items">
	 					<a href="dashboard.php" class="active" class="sidebar-link">
	 						<i class="fa-solid fa-table-columns pe-2"></i><span class="text dashboard">Dashboard</span>
	 					</a>
	 				</li>
	 				<li class="sidebar-items">
	 					<a href="user.php" class="sidebar-link">
	 						<i class="fa-regular fa-user pe-2"></i><span class="text">Users</span>
	 					</a>
	 				</li>
	 				<li class="sidebar-items">
	 					<a href="#" class="sidebar-link collapsed" data-bs-target="#manage" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-list-check pe-2"></i><span class="text">Manage</span></a>
	 					
	 					<ul id="manage" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
	 						
	 						<li class="sidebar-items">
	 						<a href="courses.php" class="sidebar-link"><i class="fa-solid fa-book pe-1"></i>Courses</a>
	 					</li>
	 					<li class="sidebar-items">
	 						<a href="rooms.php" class="sidebar-link"><i class="fa-solid fa-house-chimney pe-1"></i>Rooms</a>
	 					</li>
	 					</ul>
	 				</li>
	 				<li class="sidebar-items">
	 					<a href="schedule.php" class="sidebar-link">
	 						<i class="fa-regular fa-calendar pe-2"></i>
	 						<span class="text">Schedule</span>
	 					</a>
	 				</li>
	 				<li class="sidebar-items">
	 					<a href="reports.php" class="sidebar-link">
	 						<i class="fa-regular fa-flag pe-2"></i>
	 						<span class="text">Reports</span>
	 					</a>
	 				</li>
	 				<label for="menu-toggle">
            		<span><i class="fa-solid fa-arrow-right-to-bracket"></i></span>
        		</label>
	 			</ul>
	 		</div>
	 	</aside>
	 	<div class="main">
	 		<nav class="navbar navbar-expand"> 
	 		<img src="img/dorsulogo.png" alt="Davao Oriental State University Logo">
	 			<div class="text-header">
	 				<h1 class="school_name">DAVAO ORIENTAL STATE UNIVERSITY</h1>
                	<h6 class="faculty_name">A University of Excellece, Innovation, and Inclusion</h6>
	 			</div>
	 			<div class="navbar-collapse">
	 				<ul class="navbar-nav">
	 					<div class="side-content">
	 				<label for="section">Academic Year:</label>
                    <select id="section" name="section" required>
                    	<option ></option>
                        <option value="A">2021-2022</option>
                        <option value="B">2022-2023</option>
                        <option value="C">2023-2024</option>
                    </select>
	 					<label for="section">Semester:</label>
                    <select id="section" name="section" required>
                    	<option ></option>
                    	<option value="A">1st</option>
                        <option value="B">2nd</option>
                        
                    </select>
	 					<div class="notification">
	 						<i class="fa-regular fa-bell"></i>
	 					</div>
	 					</div>
	 					<li class="nav-item" dropdown>
	 						<a href="#" data-bs-toggle="dropdown" class="nav-icon">
	 							<img src="img/user-profile.png" class="avatar img-fluid rounded" alt="Profile">
	 						</a>
	 						<div class="dropdown-menu dropdown-menu-end">
	 							<a href="#" class="dropdwon-item"><i class="fa-solid fa-user"></i>Profile</a>
	 							<a href="#" class="dropdwon-item"><i class="fa-solid fa-gear"></i>Setting</a>
	 							<a href="index.php" class="dropdwon-item"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>
	 						</div>
	 					</li>
	 				</ul>
	 			</div>
	 		</nav>
	 		<main class="content px-3 py-2">
	 			<div class="container-fluid">
	 				<div class="mb-3">
	 					<h5>Dashboard</h5>
	 				</div>
	 				<div class="container-card1">
	 					<div class="card1"></div>
	 					<div class="card2"></div>
	 					<div class="card3"></div>
	 					<div class="card4"></div>
	 					<div class="card5"></div>
	 				</div>
	 				<div class="container-card2">
	 					<div class="card1"></div>
	 					<div class="card2"></div>
	 				</div>
	 		</main>

	 	</div>
	 </div> 
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src="js/script.js"></script>
</body>
</html>