<?php
require_once 'dbconnection.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST["username"]; 
    $password = $_POST["password"];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['status'] == 'Pending') {
            echo '<script>';
            echo 'alert("Account approval is pending. Please contact the administrator.");';
            echo 'window.location.href = "index.php";';
            echo '</script>';
        }
        elseif ($row['status'] == 'Rejected') {
            echo '<script>';
            echo 'alert("Your Account is Rejected. Please contact the administrator.");';
            echo 'window.location.href = "index.php";';
            echo '</script>';
        } elseif (password_verify($password, $row['password'])) {
            // Redirect based on user type
            if ($row['user_type'] == 'Faculty') {
                header("location: /csms/client/dashboard_faculty.php");
            } else {
                header("location: dashboard.php");
            }
            exit; // Ensure script stops execution after redirection
        } else {
            echo '<script>';
            echo 'alert("Invalid Password");';
            echo 'window.location.href = "index.php";';
            echo '</script>';
        }
    } else {
        echo '<script>';
        echo 'alert("User Not Found");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
    }

    // Close prepared statement
    $stmt->close();
}
?>
