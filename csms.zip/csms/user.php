<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .pagination-controls {
            margin: 20px 0;
            justify-content: flex-start;
        }

        .pagination-controls button {
            margin: 0 5px;
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .pagination-controls button:hover {
            background-color: gray;
        }

        .pagination-controls button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        .pagination-controls span {
            margin: 0 10px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    
    <input type="checkbox" id="menu-toggle" hidden>
    <div class="wrapper">
        <aside id="sidebar">
            <div class="top-nav">
                <div class="logo">
                    <img src="img/csmslogo.png">
                    <a>Super Admin</a>
                </div>
                <ul class="sidebar-nav">
                    <li class="sidebar-items">
                        <a href="dashboard.php" class="sidebar-link">
                            <i class="fa-solid fa-table-columns pe-2"></i><span class="text dashboard">Dashboard</span>
                        </a>
                    </li>
                    <li class="sidebar-items">
                        <a href="user.php" class="active" class="sidebar-link">
                            <i class="fa-regular fa-user pe-2"></i><span class="text">Users</span>
                        </a>
                    </li>
                    <li class="sidebar-items">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#manage" data-bs-toggle="collapse" aria-expanded="false"><i class="fa-solid fa-list-check pe-2"></i><span class="text">Manage</span></a>
                        <ul id="manage" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-items">
                            <a href="courses.php" class="sidebar-link"><i class="fa-solid fa-book pe-1"></i>Courses</a>
                        </li>
                        <li class="sidebar-items">
                            <a href="rooms.php" class="sidebar-link"><i class="fa-solid fa-house-chimney pe-1"></i>Rooms</a>
                        </li>
                        </ul>
                    </li>
                    <li class="sidebar-items">
                        <a href="schedule.php" class="sidebar-link">
                            <i class="fa-regular fa-calendar pe-2"></i>
                            <span class="text">Schedule</span>
                        </a>
                    </li>
                    <li class="sidebar-items">
                        <a href="reports.php" class="sidebar-link">
                            <i class="fa-regular fa-flag pe-2"></i>
                            <span class="text">Reports</span>
                        </a>
                    </li>
                    <label for="menu-toggle">
                    <span><i class="fa-solid fa-arrow-right-to-bracket"></i></span>
                </label>
                </ul>
            </div>
        </aside>
        <div class="main">
            <nav class="navbar navbar-expand"> 
            <img src="img/dorsulogo.png" alt="Davao Oriental State University Logo">
                <div class="text-header">
                    <h1 class="school_name">DAVAO ORIENTAL STATE UNIVERSITY</h1>
                    <h6 class="faculty_name">Faculty of Computing Data Sciences Engineering and Technology</h6>
                </div>
                <div class="navbar-collapse">
                    <ul class="navbar-nav">
                        <div class="side-content">
                        <div class="notification">
                            <i class="fa-regular fa-bell"></i>
                        </div>
                        </div>
                        <li class="nav-item" dropdown>
                            <a href="#" data-bs-toggle="dropdown" class="nav-icon">
                                <img src="img/user-profile.png" class="avatar img-fluid rounded" alt="Profile">
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="#" class="dropdwon-item"><i class="fa-regular fa-user"></i>Profile</a>
                                <a href="#" class="dropdwon-item"><i class="fa-solid fa-gear"></i>Setting</a>
                                <a href="index.php" class="dropdwon-item"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <main class="content px-3 py-2">
                <div class="container-fluid">
                    <div class="mb-3">
                        <h5>User</h5>
                    </div>
            
            <div class="browse">
                <input type="search" placeholder="Search" class="record-search" oninput="searchRecord()">
            </div>

            <!-- Pagination Controls -->
            <div class="pagination-controls">
                <button id="prevPage" disabled><i class="fa-solid fa-chevron-left"></i></button>
                <span id="pageInfo">Page 1</span>
                <button id="nextPage"><i class="fa-solid fa-chevron-right"></i></button>
            </div>
            <table id="userTable">
                <thead>
                    <tr>
                        <th>Id No</th>
                        <th>Lastname</th>
                        <th>Firstname</th>
                        <th>Middle Name</th>
                        <th>Faculty</th>
                        <th>Program</th>
                        <th>User Type</th>
                        <th>Status</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'dbconnection.php';
                    $sql = "SELECT * FROM user ORDER BY faculty ASC";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id_number = $row['id_number'];
                            $last_name = $row['last_name'];
                            $first_name = $row['first_name'];
                            $middle_name = $row['middle_name'];
                            $faculty = $row['faculty'];
                            $program = $row['program'];
                            $user_type = $row['user_type'];
                            $status = $row['status'];
                            $email = $row['email'];
                            $username = $row['username'];

                            echo '<tr>
                            <td>' . $id_number . '</td>
                            <td>' . $last_name . '</td>
                            <td>' . $first_name . '</td>
                            <td>' . $middle_name . '</td>
                            <td>' . $faculty . '</td>
                            <td>' . $program . '</td>
                            <td>' . $user_type . '</td>
                            <td>' . $status . '</td>
                            <td>' . $email . '</td>
                            <td>' . $username . '</td>
                            <td>
                                <button class="update-btn" style="color: white; background-color:green; font-size:16;"><i class="fa-regular fa-pen-to-square"></i></button>
                                <button class="delete-btn" style="color: white; background-color:red; font-size:16;"><i class="fa-regular fa-trash-can"></i></button>
                            </td>

                            </tr>';
                        }
                    }
                    ?>

                </tbody>
            </table>

            
        </main>
    </div>

</div> 
<?php include('add_modal.php') ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
   document.addEventListener('DOMContentLoaded', function() {
    const rowsPerPage = 7;
    let currentPage = 1;
    const table = document.getElementById('userTable');
    const tbody = table.querySelector('tbody');
    let rows = Array.from(tbody.querySelectorAll('tr'));
    let filteredRows = rows;
    const totalRows = rows.length;
    const totalPages = Math.ceil(totalRows / rowsPerPage);

    // Insert the No Result Found row
    const noResultRow = document.createElement('tr');
    noResultRow.id = 'noResultRow';
    noResultRow.style.display = 'none';
    noResultRow.innerHTML = '<td colspan="11" style="text-align: center;"><h3>No Result Found</h3></td>';
    tbody.appendChild(noResultRow);

    function displayRows() {
        tbody.innerHTML = '';
        const start = (currentPage - 1) * rowsPerPage;
        const end = Math.min(start + rowsPerPage, filteredRows.length);
        if (filteredRows.length === 0) {
            noResultRow.style.display = '';
            tbody.appendChild(noResultRow);
        } else {
            noResultRow.style.display = 'none';
            for (let i = start; i < end; i++) {
                tbody.appendChild(filteredRows[i]);
            }
        }
        document.getElementById('pageInfo').innerText = `Page ${currentPage} of ${Math.ceil(filteredRows.length / rowsPerPage)}`;
        document.getElementById('prevPage').disabled = currentPage === 1;
        document.getElementById('nextPage').disabled = currentPage === Math.ceil(filteredRows.length / rowsPerPage);
    }

    document.getElementById('prevPage').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            displayRows();
        }
    });

    document.getElementById('nextPage').addEventListener('click', function() {
        if (currentPage < Math.ceil(filteredRows.length / rowsPerPage)) {
            currentPage++;
            displayRows();
        }
    });

    function searchRecord() {
        const input = document.querySelector(".record-search").value.toUpperCase();
        filteredRows = rows.filter(row => {
            return Array.from(row.cells).some(cell => cell.textContent.toUpperCase().includes(input));
        });
        currentPage = 1;
        displayRows();
    }

    document.querySelector(".record-search").addEventListener('input', searchRecord);

    displayRows();
});


   document.addEventListener('DOMContentLoaded', function() {
        // Your existing code for pagination and search

        // Function to handle delete button click
        function handleDeleteButtonClick(event) {
            const button = event.target;
            const row = button.closest('tr');
            const id_number = row.cells[0].innerText; // Assuming the user ID is in the first cell

            // Ask for confirmation
            const isConfirmed = confirm('Are you sure you want to delete this user?');

            // If confirmed, redirect to delete.php with user ID as parameter
            if (isConfirmed) {
                window.location.href = 'deleteUser.php?delete=' + encodeURIComponent(id_number);
            }
        }

        // Attach event listeners to delete buttons
        const deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', handleDeleteButtonClick);
        });
    });


   document.addEventListener('DOMContentLoaded', function() {
        // Your existing code for pagination and search

        // Function to handle delete button click
        function handleDeleteButtonClick(event) {
            const button = event.target;
            const row = button.closest('tr');
            const id_number = row.cells[0].innerText; // Assuming the user ID is in the first cell

            // Ask for confirmation
            const isConfirmed = confirm('Are you sure you want to update the status of this user?');

            // If confirmed, redirect to delete.php with user ID as parameter
            if (isConfirmed) {
                window.location.href = 'updateUser.php?update=' + encodeURIComponent(id_number);
            }
        }

        // Attach event listeners to delete buttons
        const deleteButtons = document.querySelectorAll('.update-btn');
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', handleDeleteButtonClick);
        });
    });

</script>

</body>
</html>
